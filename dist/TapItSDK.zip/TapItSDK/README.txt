TapIt iOS SDK

Complete implementation instructions can be found at:
https://github.com/tapit/TapIt-iPhone-SDK
