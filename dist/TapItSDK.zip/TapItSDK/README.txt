TapIt iOS SDK
Version 3.0.7

Complete implementation instructions can be found at:
https://github.com/tapit/TapIt-iPhone-SDK
